import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-prod',
  templateUrl: './edit-prod.component.html',
  styleUrls: ['./edit-prod.component.css']
})
export class EditProdComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
