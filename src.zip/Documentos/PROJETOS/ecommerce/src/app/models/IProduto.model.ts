export interface IProduto {
    
         id_produto: number,
         id_grupo: number,
         id_marca: number,
         id_locacao: number,
         nome: string,
         custo: number,
         preco: number,
         qtd_estoque: number,
         imagem_produto: string,
                           
}