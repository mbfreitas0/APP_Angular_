import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cadastrar-produto',
  templateUrl: './cadastrar-produto.component.html',
  styleUrls: ['./cadastrar-produto.component.css']
})
export class CadastrarProdutoComponent implements OnInit {

         id_produto: number;
         id_grupo: number;
         id_marca: number;
         id_locacao: number;
         nome: string;
         custo: number;
         preco: number;
         qtd_estoque: number;

  constructor() { }

  ngOnInit(): void {
  }
  
  salvarProduto() {
    console.log('Nome: ',this.nome);
    console.log('Grupo: ',this.id_grupo);
    console.log('Marca: ',this.id_marca);
    console.log('Locacao: ',this.id_locacao);
    console.log('Custo: ',this.custo);
    console.log('Preco: ',this.preco);
    console.log('Estoque: ',this.qtd_estoque);
    alert('Salvo com sucesso !');
  }

}
