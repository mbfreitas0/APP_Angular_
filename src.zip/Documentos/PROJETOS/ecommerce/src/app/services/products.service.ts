import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IProduto } from '../models/IProduto.model';

@Injectable({
  providedIn: 'root'
   
})
export class ProdutoService {


  private URL: string = 'http://localhost:3000/produtos';
   
  constructor( private http: HttpClient ){ }

  buscarTodos(): Observable<IProduto[]> {
    return this.http.get<IProduto[]>(this.URL);

  }

  

  
} 